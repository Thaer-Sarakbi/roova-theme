<?php
/**
 * Shared data helpers: hotel + room meta, dates, and the current search criteria.
 *
 * @package Roova
 */

defined( 'ABSPATH' ) || exit;

/**
 * Theme option (Customizer setting) with a default.
 *
 * @param string $key     Option key without the roova_ prefix.
 * @param mixed  $default Default value.
 * @return mixed
 */
function roova_option( $key, $default = '' ) {
	return get_theme_mod( 'roova_' . $key, $default );
}

/* -------------------------------------------------------------------------
 * Homepage content
 * ---------------------------------------------------------------------- */

/**
 * The stock wording for the four booking promises.
 *
 * Slot numbers match the Customizer settings (roova_guarantee_1_title etc.).
 *
 * @return array[] Slot number => array( icon, title, body ).
 */
function roova_guarantee_defaults() {
	return array(
		1 => array(
			'icon'  => 'best-rate',
			'title' => __( 'Best Rate Guarantee', 'roova' ),
			'body'  => __( 'Book direct and we match — or beat — any lower rate you find elsewhere.', 'roova' ),
		),
		2 => array(
			'icon'  => 'no-fees',
			'title' => __( 'Zero Booking Fees', 'roova' ),
			'body'  => __( 'No hidden service charges or OTA mark-ups added at checkout.', 'roova' ),
		),
		3 => array(
			'icon'  => 'instant',
			'title' => __( 'Instant Confirmation', 'roova' ),
			'body'  => __( 'Your room is held the moment you pay — no waiting on an email.', 'roova' ),
		),
		4 => array(
			'icon'  => 'support',
			'title' => __( '24/7 Local Support', 'roova' ),
			'body'  => __( 'Reach our Malaysia-based team by phone or WhatsApp, any hour.', 'roova' ),
		),
	);
}

/**
 * The four promises in the homepage guarantees row.
 *
 * Titles and bodies are Customizer settings so the client can reword them or
 * drop a promise they cannot honour; the icons are fixed per slot.
 *
 * @return array[] Each: icon, title, body.
 */
function roova_guarantees() {
	$items = array();

	foreach ( roova_guarantee_defaults() as $slot => $item ) {
		$title = roova_option( 'guarantee_' . $slot . '_title', $item['title'] );
		$body  = roova_option( 'guarantee_' . $slot . '_body', $item['body'] );

		// An emptied title switches the promise off.
		if ( '' === trim( (string) $title ) ) {
			continue;
		}

		$items[] = array(
			'icon'  => $item['icon'],
			'title' => $title,
			'body'  => $body,
		);
	}

	/**
	 * Filter the homepage guarantees.
	 *
	 * @param array[] $items Each: icon, title, body.
	 */
	return apply_filters( 'roova_guarantees', $items );
}

/**
 * The popular searches shown as pills under the hero search bar.
 *
 * One per line in the Customizer, either "Label" or "Label | destination-slug".
 *
 * @return array[] Each: label, url.
 */
function roova_popular_searches() {
	$raw   = (string) roova_option( 'popular_searches', '' );
	$items = array();

	foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}

		$label = $line;
		$term  = $line;
		if ( false !== strpos( $line, '|' ) ) {
			$parts = explode( '|', $line, 2 );
			$label = trim( $parts[0] );
			$term  = trim( $parts[1] );
		}

		if ( '' === $label ) {
			continue;
		}

		$items[] = array(
			'label' => $label,
			'url'   => function_exists( 'roova_destination_url' ) ? roova_destination_url( $term ) : home_url( '/' ),
		);
	}

	/**
	 * Filter the popular searches under the hero.
	 *
	 * @param array[] $items Each: label, url.
	 */
	return apply_filters( 'roova_popular_searches', $items );
}

/**
 * Is the coverage map being rendered on this request?
 *
 * Decides both whether the section is printed and whether the map libraries
 * are loaded, so the two can never disagree.
 *
 * @return bool
 */
function roova_show_coverage_map() {
	if ( ! is_front_page() || is_paged() || ! roova_has_woocommerce() ) {
		return false;
	}

	if ( ! roova_option( 'show_map', true ) ) {
		return false;
	}

	return function_exists( 'roova_map_places' ) && (bool) roova_map_places();
}

/**
 * The mosaic class for a destination tile.
 *
 * The design's rhythm is a 2x2 anchor, then four single tiles, then wide
 * tiles — repeated for as many destinations as the site has.
 *
 * @param int $index Zero-based position in the grid.
 * @return string Extra CSS class, or ''.
 */
function roova_destination_span_class( $index ) {
	$position = (int) $index % 7;

	if ( 0 === $position ) {
		return 'roova-destination--wide roova-destination--tall';
	}

	if ( $position >= 5 ) {
		return 'roova-destination--wide';
	}

	return '';
}

/* -------------------------------------------------------------------------
 * Dates
 * ---------------------------------------------------------------------- */

/**
 * Normalise a date string to Y-m-d, or return '' when it is not a real date.
 *
 * @param string $value Raw date.
 * @return string
 */
function roova_sanitize_date( $value ) {
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return '';
	}
	$date = DateTime::createFromFormat( 'Y-m-d', $value );
	if ( ! $date || $date->format( 'Y-m-d' ) !== $value ) {
		return '';
	}
	return $value;
}

/**
 * Today in the site's timezone as Y-m-d.
 *
 * @return string
 */
function roova_today() {
	return current_time( 'Y-m-d' );
}

/**
 * Add days to a Y-m-d date.
 *
 * @param string $date Date.
 * @param int    $days Days to add (may be negative).
 * @return string
 */
function roova_add_days( $date, $days ) {
	$dt = new DateTime( $date . ' 00:00:00' );
	$dt->modify( sprintf( '%+d days', (int) $days ) );
	return $dt->format( 'Y-m-d' );
}

/**
 * Number of nights between two dates. Zero or less means an invalid stay.
 *
 * @param string $check_in  Check-in date.
 * @param string $check_out Check-out date.
 * @return int
 */
function roova_nights( $check_in, $check_out ) {
	$check_in  = roova_sanitize_date( $check_in );
	$check_out = roova_sanitize_date( $check_out );
	if ( ! $check_in || ! $check_out ) {
		return 0;
	}
	$in  = new DateTime( $check_in . ' 00:00:00' );
	$out = new DateTime( $check_out . ' 00:00:00' );
	if ( $out <= $in ) {
		return 0;
	}
	return (int) $in->diff( $out )->days;
}

/**
 * Every night (stay date) in a range. Check-out day is not a night.
 *
 * @param string $check_in  Check-in date.
 * @param string $check_out Check-out date.
 * @return string[] Y-m-d dates.
 */
function roova_night_list( $check_in, $check_out ) {
	$nights = roova_nights( $check_in, $check_out );
	$dates  = array();
	for ( $i = 0; $i < $nights; $i++ ) {
		$dates[] = roova_add_days( $check_in, $i );
	}
	return $dates;
}

/**
 * Format a date the way the design shows it: "Aug 29 / 2026".
 *
 * @param string $date Y-m-d date.
 * @return string
 */
function roova_format_date( $date ) {
	$date = roova_sanitize_date( $date );
	if ( ! $date ) {
		return '';
	}
	return date_i18n( 'M j / Y', strtotime( $date . ' 00:00:00' ) );
}

/* -------------------------------------------------------------------------
 * Search criteria
 * ---------------------------------------------------------------------- */

/**
 * Default search criteria: tomorrow to the day after, one room, two adults.
 *
 * @return array
 */
function roova_default_criteria() {
	return array(
		'destination' => '',
		'hotel_id'    => 0,
		'check_in'    => roova_add_days( roova_today(), 1 ),
		'check_out'   => roova_add_days( roova_today(), 2 ),
		'rooms'       => 1,
		'adults'      => 2,
		'children'    => 0,
	);
}

/**
 * Read the visitor's search criteria: request first, then session, then defaults.
 *
 * Read-only — no nonce needed, these are shareable GET search parameters.
 *
 * @return array
 */
function roova_get_criteria() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}

	$criteria = roova_default_criteria();

	$stored = roova_session_get( 'roova_criteria' );
	if ( is_array( $stored ) ) {
		$criteria = array_merge( $criteria, $stored );
	}

	$from_request = false;
	// phpcs:disable WordPress.Security.NonceVerification.Recommended
	if ( isset( $_GET['roova_dest'] ) ) {
		$criteria['destination'] = sanitize_text_field( wp_unslash( $_GET['roova_dest'] ) );
		$from_request            = true;
	}
	if ( isset( $_GET['roova_hotel'] ) ) {
		$criteria['hotel_id'] = absint( $_GET['roova_hotel'] );
		$from_request         = true;
	}
	if ( isset( $_GET['checkin'] ) ) {
		$date = roova_sanitize_date( sanitize_text_field( wp_unslash( $_GET['checkin'] ) ) );
		if ( $date ) {
			$criteria['check_in'] = $date;
			$from_request         = true;
		}
	}
	if ( isset( $_GET['checkout'] ) ) {
		$date = roova_sanitize_date( sanitize_text_field( wp_unslash( $_GET['checkout'] ) ) );
		if ( $date ) {
			$criteria['check_out'] = $date;
			$from_request          = true;
		}
	}
	foreach ( array( 'rooms', 'adults', 'children' ) as $key ) {
		if ( isset( $_GET[ $key ] ) ) {
			$criteria[ $key ] = absint( $_GET[ $key ] );
			$from_request     = true;
		}
	}
	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	$criteria = roova_normalise_criteria( $criteria );

	if ( $from_request ) {
		roova_session_set( 'roova_criteria', $criteria );
	}

	$cache = $criteria;
	return $cache;
}

/**
 * Clamp criteria into a usable shape: a stay in the future of at least one night.
 *
 * @param array $criteria Raw criteria.
 * @return array
 */
function roova_normalise_criteria( $criteria ) {
	$defaults = roova_default_criteria();
	$criteria = wp_parse_args( $criteria, $defaults );

	$criteria['check_in']  = roova_sanitize_date( $criteria['check_in'] );
	$criteria['check_out'] = roova_sanitize_date( $criteria['check_out'] );

	if ( ! $criteria['check_in'] || $criteria['check_in'] < roova_today() ) {
		$criteria['check_in'] = $defaults['check_in'];
	}
	if ( ! $criteria['check_out'] || $criteria['check_out'] <= $criteria['check_in'] ) {
		$criteria['check_out'] = roova_add_days( $criteria['check_in'], 1 );
	}

	$max_nights = (int) apply_filters( 'roova_max_nights', 60 );
	if ( roova_nights( $criteria['check_in'], $criteria['check_out'] ) > $max_nights ) {
		$criteria['check_out'] = roova_add_days( $criteria['check_in'], $max_nights );
	}

	$criteria['rooms']    = max( 1, min( 8, (int) $criteria['rooms'] ) );
	$criteria['adults']   = max( 1, min( 16, (int) $criteria['adults'] ) );
	$criteria['children'] = max( 0, min( 12, (int) $criteria['children'] ) );
	$criteria['hotel_id'] = absint( $criteria['hotel_id'] );

	return $criteria;
}

/**
 * Build a URL with the criteria applied as query args.
 *
 * @param string $url      Base URL.
 * @param array  $criteria Criteria.
 * @return string
 */
function roova_criteria_url( $url, $criteria = null ) {
	$criteria = $criteria ? roova_normalise_criteria( $criteria ) : roova_get_criteria();
	$args     = array(
		'checkin'  => $criteria['check_in'],
		'checkout' => $criteria['check_out'],
		'rooms'    => $criteria['rooms'],
		'adults'   => $criteria['adults'],
		'children' => $criteria['children'],
	);
	if ( $criteria['destination'] ) {
		$args['roova_dest'] = $criteria['destination'];
	}
	return add_query_arg( $args, $url );
}

/**
 * The search results page URL.
 *
 * @return string
 */
function roova_search_url() {
	$page_id = (int) get_option( 'roova_search_page_id' );
	if ( $page_id && 'publish' === get_post_status( $page_id ) ) {
		return get_permalink( $page_id );
	}
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		return wc_get_page_permalink( 'shop' );
	}
	return home_url( '/' );
}

/* -------------------------------------------------------------------------
 * Session (WooCommerce session, with a graceful no-op fallback)
 * ---------------------------------------------------------------------- */

/**
 * Read a value from the WooCommerce session.
 *
 * @param string $key Key.
 * @return mixed|null
 */
function roova_session_get( $key ) {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return null;
	}
	return WC()->session->get( $key );
}

/**
 * Write a value to the WooCommerce session.
 *
 * @param string $key   Key.
 * @param mixed  $value Value.
 */
function roova_session_set( $key, $value ) {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return;
	}
	WC()->session->set( $key, $value );
}

/**
 * Stable identifier for the current visitor's cart, used to own booking holds.
 *
 * @return string
 */
function roova_session_id() {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return '';
	}
	$id = WC()->session->get_customer_id();
	return $id ? (string) $id : '';
}

/* -------------------------------------------------------------------------
 * Hotels
 * ---------------------------------------------------------------------- */

/**
 * Hotel detail meta with defaults applied.
 *
 * @param int $hotel_id Hotel product ID.
 * @return array
 */
function roova_get_hotel_details( $hotel_id ) {
	$hotel_id = absint( $hotel_id );
	$keys     = array(
		'address'            => '',
		'lat'                => '',
		'lng'                => '',
		'map_zoom'           => '15',
		'map_link'           => '',
		'map_place_id'       => '',
		'checkin_time'       => '15:00',
		'checkout_time'      => '12:00',
		'stars'              => '0',
		'score'              => '',
		'score_label'        => '',
		'review_count'       => '',
		'score_cleanliness'  => '',
		'score_location'     => '',
		'score_service'      => '',
		'landmarks_popular'  => '',
		'landmarks_nearby'   => '',
		'phone'              => '',
	);

	$details = array();
	foreach ( $keys as $key => $default ) {
		$value           = get_post_meta( $hotel_id, '_roova_' . $key, true );
		$details[ $key ] = ( '' === $value || null === $value ) ? $default : $value;
	}

	return $details;
}

/**
 * A phone number reduced to something a `tel:` link can dial.
 *
 * Keeps the digits and a leading "+" only: everything a client types for
 * legibility — spaces, brackets, dashes — either does nothing in a dialler or
 * stops the link working. Returns an empty string when there are no digits at
 * all, so a caller can use it to decide whether to link the number.
 *
 * @param string $phone Phone number as entered.
 * @return string
 */
function roova_tel_href( $phone ) {
	$phone  = trim( (string) $phone );
	$plus   = ( 0 === strpos( $phone, '+' ) ) ? '+' : '';
	$digits = preg_replace( '/\D+/', '', $phone );

	return $digits ? $plus . $digits : '';
}

/**
 * Parse a landmark textarea into name/distance pairs.
 *
 * One landmark per line, optionally "Name | 1.2 km".
 *
 * @param string $raw Raw textarea contents.
 * @return array[] Each item: array( 'name' => string, 'distance' => string ).
 */
function roova_parse_landmarks( $raw ) {
	$items = array();
	$lines = preg_split( '/\r\n|\r|\n/', (string) $raw );
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$name     = $line;
		$distance = '';
		if ( false !== strpos( $line, '|' ) ) {
			$parts    = explode( '|', $line, 2 );
			$name     = trim( $parts[0] );
			$distance = trim( $parts[1] );
		}
		if ( '' === $name ) {
			continue;
		}
		$items[] = array(
			'name'     => $name,
			'distance' => $distance,
		);
	}
	return $items;
}

/**
 * A hotel's popular landmarks, parsed.
 *
 * @param int $hotel_id Hotel product ID.
 * @return array[] Each item: array( 'name' => string, 'distance' => string ).
 */
function roova_hotel_popular_landmarks( $hotel_id ) {
	$details = roova_get_hotel_details( $hotel_id );

	return roova_parse_landmarks( $details['landmarks_popular'] );
}

/**
 * One popular landmark to print beside the hotel's location, with its distance.
 *
 * Picked at random, but seeded from the hotel ID rather than the clock: a card
 * that reshuffled on every refresh would read as a page that cannot make up its
 * mind, and would differ between a cached copy and a fresh one. Same hotel,
 * same landmark, every time — until the site owner edits the list.
 *
 * Only landmarks that carry a distance are considered; the whole point of the
 * line is "how far is it from something you have heard of".
 *
 * @param int $hotel_id Hotel product ID.
 * @return array|null array( 'name', 'distance' ), or null when there is none.
 */
function roova_hotel_feature_landmark( $hotel_id ) {
	$hotel_id = absint( $hotel_id );

	$landmarks = array();
	foreach ( roova_hotel_popular_landmarks( $hotel_id ) as $landmark ) {
		if ( '' !== $landmark['distance'] ) {
			$landmarks[] = $landmark;
		}
	}

	if ( ! $landmarks ) {
		return null;
	}

	/*
	 * hexdec() over six hex digits of the hash, so the seed is a positive
	 * integer well inside range on a 32-bit build — crc32() is not.
	 */
	$seed  = hexdec( substr( md5( 'roova-landmark-' . $hotel_id ), 0, 6 ) );
	$index = (int) ( $seed % count( $landmarks ) );

	/**
	 * Filter the landmark shown beside a hotel's location.
	 *
	 * @param array $landmark  array( 'name', 'distance' ).
	 * @param int   $hotel_id  Hotel product ID.
	 * @param array $landmarks Every popular landmark that carries a distance.
	 */
	return apply_filters( 'roova_hotel_feature_landmark', $landmarks[ $index ], $hotel_id, $landmarks );
}

/**
 * All published hotel products.
 *
 * @param array $args Extra WP_Query args.
 * @return int[] Hotel product IDs.
 */
function roova_get_hotel_ids( $args = array() ) {
	$defaults = array(
		'post_type'              => 'product',
		'post_status'            => 'publish',
		'posts_per_page'         => -1,
		'fields'                 => 'ids',
		'orderby'                => 'menu_order title',
		'order'                  => 'ASC',
		'no_found_rows'          => true,
		'update_post_term_cache' => false,
		'tax_query'              => array(
			array(
				'taxonomy' => 'product_type',
				'field'    => 'slug',
				'terms'    => 'hotel',
			),
		),
	);

	$query = new WP_Query( wp_parse_args( $args, $defaults ) );
	return array_map( 'absint', $query->posts );
}

/**
 * Is this product one of the hotels?
 *
 * @param int $product_id Product ID.
 * @return bool
 */
function roova_is_hotel( $product_id ) {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return false;
	}

	$product = wc_get_product( absint( $product_id ) );

	return (bool) $product && 'hotel' === $product->get_type();
}

/**
 * A Google Maps URL, or '' for anything that is not one.
 *
 * The client pastes whatever the Share button gave them, so this accepts the
 * short links (maps.app.goo.gl, goo.gl) as well as the long google.com/maps
 * ones, on any of Google's country domains. Anything else is refused rather
 * than printed: this URL is put behind the map on every hotel page.
 *
 * @param string $url Raw value.
 * @return string
 */
function roova_maps_link( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return '';
	}

	$url  = esc_url_raw( $url, array( 'http', 'https' ) );
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );

	if ( ! $host ) {
		return '';
	}

	// google.com, google.com.my, google.co.uk … and the two short domains.
	if ( preg_match( '/(^|\.)google\.[a-z]{2,3}(\.[a-z]{2})?$/', $host ) || preg_match( '/(^|\.)goo\.gl$/', $host ) ) {
		return $url;
	}

	return '';
}

/**
 * Where "open in Google Maps" goes for a hotel.
 *
 * Deliberately *not* the coordinates: a lat/lng query opens a dropped pin on a
 * blank patch of map, with no name, no photos, no reviews and no hours. In
 * order:
 *
 * 1. The Google Maps link the client pasted on the Hotel Details tab — the one
 *    thing that is certainly the right place.
 * 2. The place the address picker found, as a place ID alongside the address.
 *    That opens Google's own listing for the hotel.
 * 3. The hotel's name and address as a search.
 * 4. The coordinates, only when there is nothing else to go on.
 *
 * @param int $hotel_id Hotel product ID.
 * @return string
 */
function roova_hotel_map_url( $hotel_id ) {
	$hotel_id = absint( $hotel_id );
	$details  = roova_get_hotel_details( $hotel_id );

	$link = roova_maps_link( $details['map_link'] );
	if ( $link ) {
		return $link;
	}

	$name     = get_the_title( $hotel_id );
	$address  = trim( preg_replace( '/\s+/', ' ', (string) $details['address'] ) );
	$place_id = trim( (string) $details['map_place_id'] );
	$query    = trim( $name . ( $address ? ', ' . $address : '' ), ', ' );

	if ( ! $query ) {
		$lat = trim( (string) $details['lat'] );
		$lng = trim( (string) $details['lng'] );

		if ( ! $lat || ! $lng ) {
			return '';
		}

		$query = $lat . ',' . $lng;
	}

	$args = array( 'api' => '1', 'query' => $query );

	if ( $place_id ) {
		$args['query_place_id'] = $place_id;
	}

	return add_query_arg( array_map( 'rawurlencode', $args ), 'https://www.google.com/maps/search/' );
}

/**
 * Is this request a hotel's own page (single-hotel.php)?
 *
 * @return bool
 */
function roova_is_hotel_page() {
	return is_singular( 'product' ) && roova_is_hotel( get_queried_object_id() );
}

/**
 * Rooms that belong to a hotel.
 *
 * @param int $hotel_id Hotel product ID.
 * @return int[] Room product IDs.
 */
function roova_get_hotel_room_ids( $hotel_id ) {
	$hotel_id = absint( $hotel_id );
	if ( ! $hotel_id ) {
		return array();
	}

	$query = new WP_Query( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'orderby'        => 'menu_order title',
		'order'          => 'ASC',
		'no_found_rows'  => true,
		'meta_query'     => array(
			array(
				'key'   => '_roova_hotel_id',
				'value' => $hotel_id,
			),
		),
		'tax_query'      => array(
			array(
				'taxonomy' => 'product_type',
				'field'    => 'slug',
				'terms'    => 'room',
			),
		),
	) );

	return array_map( 'absint', $query->posts );
}

/**
 * The hotel a room belongs to.
 *
 * @param int $room_id Room product ID.
 * @return int Hotel product ID, or 0.
 */
function roova_get_room_hotel_id( $room_id ) {
	return absint( get_post_meta( absint( $room_id ), '_roova_hotel_id', true ) );
}

/**
 * Room settings with defaults.
 *
 * @param int $room_id Room product ID.
 * @return array
 */
function roova_get_room_details( $room_id ) {
	$room_id = absint( $room_id );

	$units = get_post_meta( $room_id, '_roova_units', true );
	$units = ( '' === $units ) ? 1 : (int) $units;

	$max_adults   = (int) get_post_meta( $room_id, '_roova_max_adults', true );
	$max_children = (int) get_post_meta( $room_id, '_roova_max_children', true );

	return array(
		'hotel_id'     => roova_get_room_hotel_id( $room_id ),
		'units'        => max( 0, $units ),
		'max_adults'   => $max_adults > 0 ? $max_adults : 2,
		'max_children' => max( 0, $max_children ),
		'size'         => (string) get_post_meta( $room_id, '_roova_size', true ),
		'beds'         => (string) get_post_meta( $room_id, '_roova_beds', true ),
		'min_nights'   => max( 1, (int) get_post_meta( $room_id, '_roova_min_nights', true ) ),
		'view'         => (string) get_post_meta( $room_id, '_roova_view', true ),
	);
}

/**
 * Can a room hold this party (per unit booked)?
 *
 * @param int $room_id  Room product ID.
 * @param int $adults   Adults in total.
 * @param int $children Children in total.
 * @param int $units    Units being booked.
 * @return bool
 */
function roova_room_fits( $room_id, $adults, $children, $units = 1 ) {
	$details = roova_get_room_details( $room_id );
	$units   = max( 1, (int) $units );

	if ( $adults > $details['max_adults'] * $units ) {
		return false;
	}
	if ( $children > $details['max_children'] * $units ) {
		return false;
	}
	return true;
}

/**
 * Nightly rate for a room.
 *
 * @param int $room_id Room product ID.
 * @return float
 */
function roova_room_rate( $room_id ) {
	$product = wc_get_product( $room_id );
	if ( ! $product ) {
		return 0.0;
	}
	return (float) $product->get_price();
}

/**
 * Destination terms attached to a hotel.
 *
 * @param int $hotel_id Hotel product ID.
 * @return WP_Term[]
 */
function roova_get_hotel_destinations( $hotel_id ) {
	$terms = get_the_terms( absint( $hotel_id ), 'pa_destination' );
	return is_array( $terms ) ? $terms : array();
}

/**
 * A short "City, Region" label for a hotel, taken from its destination terms.
 *
 * @param int $hotel_id Hotel product ID.
 * @return string
 */
function roova_hotel_location_label( $hotel_id ) {
	$terms = roova_get_hotel_destinations( $hotel_id );
	if ( $terms ) {
		return $terms[0]->name;
	}
	$details = roova_get_hotel_details( $hotel_id );
	return $details['address'];
}
